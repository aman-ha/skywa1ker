<p align="center">
  <img src="/img/pizza.png" width="600px" alt="Pizza Shop WebApp" />
</p>

# Pizza Shop Website
Pizza Shop web app that allows users to Sign Up, Sign In, and Admins to control pizzas and ingredients, using JavaScript, HTML5, CSS3 and REST API hosted on a server.

Free images got from URL: https://unsplash.com/
